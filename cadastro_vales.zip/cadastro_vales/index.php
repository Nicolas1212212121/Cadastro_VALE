<?php 
include_once"conecxao.php";
include_once"funcoes.php";

if ($_SERVER['REQUEST_METHOD'] == "POST"){
    //Captura os dados digitando em form e salva em variaveis
    //para facilitar a manipulação dos dados 
    $descricao= $_POST['descricao'];
    $data_vale=$_POST['data_vale'];
    $valor  =$_POST['valor'];
    

    //vamos abrir a conexao com o banco de dados 
    $conecxaoComBanco = abrirBanco();
    
    //vamos criar o SQL para realizar o insert dos dados no BD 
    $sql =" INSERT INTO cadastro(descricao, data_vale, valor)
        VALUES('$descricao', '$data_vale', '$valor')";

    if ($conecxaoComBanco->query($sql) === TRUE){

        echo ":) Sucesso ao cadastrar o contato :)";
    }else{
        echo":( Erro ao cadastrar o contato :(";

    }
        

}

if(isset($_GET['acao'])&&$_GET['acao']=='deletar'){
    $id = $_GET['id'];

    $conecxaoBanco=abrirBanco();

    $sql ="DELETE FROM cadastro WHERE id=$id";

    
    if($conecxaoBanco->query($sql)===TRUE){
        echo"Conta excluida com sucesso";
    }else{
        echo"Erro ao excluir contato: ".$conecxaoBanco->error;
    }

    fecharBanco($conecxaoBanco);

}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/akame.css">
    <title>Document</title>
</head>
<body>
<header>
    <h1>Gerenciar Valores</h1>
    <hr>
    <br>
    <br>
</header>
<div class="Akame">
<div>
<h2>Cadastro Valores</h2>
<section >
    
    <form method="POST">
    <label for="">Descricao</label>
    <input type="text" name="descricao" id="descricao">
    
    <label for="">Data valor</label>
    <input type="date" name="data_vale" id="data_vale">
    
    <label for="">Valor</label>
    <input type="number" name="valor" id="valor">
    
    <button  type="submit" class="button">Salvar</button>
    </form>
</section>
</div>
<section>
    <h2>Lista de contatos</h2>
    <br>
    <table>
        <thead>
            <TR>
                <td>ID</td>
                <td>Descricao</td>
                <td>Data valor</td>
                <td>Valor</td>
                
                
            </TR>
        </thead>
        <tbody>
        <?php 
        $conecxaoBanco=abrirBanco();

        $sql="SELECT*FROM cadastro";

        $result = $conecxaoBanco->query($sql);
        
        if($result->num_rows>0){
            while($registro=$result->fetch_assoc()){
                ?>
<tr>
                <td><?=$registro['id']?></td>

                <td><?=$registro['descricao']?></td>

                <td><?=$registro['data_vale']?></td>

                <td><?=$registro['valor']?></td>

                
                <td>
                    <a href="?acao=deletar&id=<?=$registro['id']?>" onclick="return confirm('Tem certeza que deseja excluir os dados')"><button>Excluir</button></a>
                    <a href="editar.php?id=<?=$registro['id']?>"><button >Editar</button></a>

                </td>
                </tr>
                <?php
            }
        }else{
            echo ("<tr><td colspan='6'>Nenhum resistro encontrado</td></tr>") ;
        }

        ?>
            <tr>
                

            </tr>
        </tbody>
    </table>
</section>
</html>