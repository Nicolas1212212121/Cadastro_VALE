<?php 
include_once"conecxao.php";
include_once"funcoes.php";

if(isset($_GET['id'])&&$_GET['id']>0){
    $id = $_GET['id'];

    $conecxaoBanco=abrirBanco();

    $pegarDados=$conecxaoBanco->prepare("SELECT * FROM cadastro WHERE id = ?");

    $pegarDados->bind_param("i",$id);

    $pegarDados->execute();
    $result= $pegarDados->get_result();

    if($result->num_rows==1){
        $registro=$result->fetch_assoc();
    }

    fecharBanco($conecxaoBanco);

}

if($_SERVER['REQUEST_METHOD']=="POST"){
    $conecxaoComBanco=abrirBanco();

    $descricao= $_POST['descricao'];
    $data_vale=$_POST['data_vale'];
    $valor  =$_POST['valor'];

    

    $sql="UPDATE cadastro SET descricao ='$descricao',
    data_vale ='$data_vale',valor ='$valor' WHERE id=$id";

    if ($conecxaoComBanco->query($sql)===TRUE){
        echo "Contato atualizado com sucesso no banco de dados";
    }else{
        echo"Erro ao atualizado no banco de dados";
    }

    fecharBanco($conecxaoComBanco);
}

?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/akame.css">
    <title>Document</title>
</head>
<body >
    
<header>
    <h1>Atualazar Contatos</h1>
    <br>
<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
    </ul>
</nav>
</header>
<div class="Akame">
<div>
<h2>Atualazar contatos</h2>
<section >
    
    <form action="" method="POST">
    <label for="">Descricao</label>
    <input type="text" name="descricao" value="<?=$registro['descricao']?>">
    
    <label for="">Data Vale</label>
    <input type="date" name="data_vale"  value="<?=$registro['data_vale']?>">
    
    <label for="">Valor</label>
    <input type="text" name="valor"  value="<?=$registro['valor']?>">

    <input type="hidden" name="id" value="<?=$registro['id']?>">

    <button type="submit" class="button">Atualazar</button>
    </form>
</section>
</div>